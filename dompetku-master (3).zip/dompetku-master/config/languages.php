<?php

    /*
    |--------------------------------------------------------------------------
    | Available Languages
    |--------------------------------------------------------------------------
    |
    | This config control available language in footer page.
    */

    return [
        'id' => 'Bahasa Indonesia',
        'en' => 'English',
    ];
